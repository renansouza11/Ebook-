# The Stronger Years Cookbook — Vercel + Stripe Payment Link

Os quatro botões de compra levam ao Payment Link informado: https://buy.stripe.com/00w5kFb4W6Dm8CQgq5bII00. O site passa antes por `/api/checkout` para registrar no navegador, em cookie seguro, uma referência anônima. O visitante é então redirecionado ao mesmo link da Stripe com `client_reference_id`. É essa referência que permite restringir o download ao navegador da compra.

## Publicação

1. Extraia o ZIP e coloque o projeto completo em um repositório privado Git. Importe-o na Vercel com a raiz na pasta que contém `vercel.json` e `package.json`. Use Framework Preset: Other. O projeto publica `public/` e as funções de `api/`; `private/ebook.pdf` fica fora dos arquivos públicos e é incluído apenas na função de download.
2. Defina em Project Settings → Environment Variables: `SITE_URL` com a origem HTTPS definitiva (ex.: `https://seusite.vercel.app`, sem caminho), `STRIPE_RESTRICTED_KEY`, `STRIPE_WEBHOOK_SECRET` e `DOWNLOAD_SIGNING_SECRET`. Configure os três segredos como Sensitive. Para gerar o último, execute no seu computador: `node -e "console.log(require('node:crypto').randomBytes(32).toString('hex'))"`. Não inclua chaves em repositórios, HTML ou mensagens.
3. **Na configuração desse Payment Link na Stripe**, abra **After the payment → Redirect to your website** e defina exatamente `https://SEU-DOMINIO/download?session_id={CHECKOUT_SESSION_ID}`. Mantenha as chaves `{}` literais. Sem esse redirecionamento, a compra pode ser concluída, mas o comprador não recebe automaticamente a página com o botão de download.
4. Cadastre na Stripe um destino webhook para `https://SEU-DOMINIO/api/webhook`, com os eventos `checkout.session.completed`, `checkout.session.async_payment_succeeded` e `checkout.session.async_payment_failed`. Coloque o segredo `whsec_...` do destino correspondente em `STRIPE_WEBHOOK_SECRET` na Vercel e faça novo deploy.
5. Use uma chave restrita `rk_...` da **mesma conta Stripe do Payment Link**. Ela precisa de permissão de leitura para Payment Links, Checkout Sessions, PaymentIntents e Charges, além de atualização de Checkout Sessions para registrar a liberação. Ajuste cada permissão no sandbox conforme os retornos da API. Chaves de sandbox e produção são diferentes.
6. Verifique no painel Stripe se o Payment Link cobra **US$9 uma vez** pelo ebook. O site anuncia US$9 e exige uma sessão paga de US$9 para permitir download. Se o link cobrar outro valor ou moeda, **não publique os botões ainda**: corrija o Payment Link e confirme a URL final antes de vender.
7. Teste uma compra em ambiente de sandbox com um Payment Link de teste equivalente antes de vender. O link informado começa com `https://buy.stripe.com/` e parece ser de produção; não é apropriado para comprar com cartão de teste. Confira o evento webhook com resposta 200 e faça o download em `/download`. Também teste pagamento pendente, falha, reembolso, link expirado e outro navegador.

## Entrega

O webhook com assinatura verificada confere a compra e registra o primeiro momento de liberação. O acesso dura 24 horas a partir dessa confirmação. Cada URL de download expira em 15 minutos e pode ser renovada na página dentro da janela de 24 horas. O servidor confere a cada acesso se a sessão veio **do Payment Link exato** informado acima, se está paga em USD 9 e se não houve reembolso ou disputa. O PDF é transmitido apenas pela função, nunca como arquivo público. A página não envia o material por e-mail.

O comprador deve usar o mesmo navegador em que clicou no botão e fez o pagamento. Se ele visitar o Payment Link diretamente fora do site, a compra não terá o cookie necessário para o download automático. Mantenha um canal de atendimento para recuperar compras feitas fora do site, cookies apagados ou prazo encerrado. A proteção controla o acesso no servidor; depois de baixado, o PDF pode ser compartilhado por quem o recebeu.

## Verificação feita

15 testes locais passaram, incluindo redirecionamento para o Payment Link correto, associação ao navegador, pagamentos pendentes, webhook, outro Payment Link, reembolso e streaming do PDF real. Ainda é necessário validar o deploy da Vercel, a configuração do Payment Link e uma compra real após a publicação.

Documentação: https://docs.stripe.com/payment-links/url-parameters · https://docs.stripe.com/payment-links/post-payment · https://vercel.com/docs/functions/runtimes/node-js
