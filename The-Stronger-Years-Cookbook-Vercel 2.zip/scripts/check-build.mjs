import { existsSync, readFileSync, readdirSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
for (const path of ['public/index.html','public/download.html','private/ebook.pdf','vercel.json']) if (!existsSync(path)) throw new Error('Missing required file: ' + path);
if (!readFileSync('private/ebook.pdf').subarray(0,5).equals(Buffer.from('%PDF-'))) throw new Error('Invalid ebook');
if (readdirSync('public', { recursive: true }).some(x => x.endsWith('.pdf'))) throw new Error('PDF must remain private');
if (/hotmart/i.test(readFileSync('public/index.html','utf8'))) throw new Error('Outdated payment reference');
if ((readFileSync('public/index.html','utf8').match(/href="\/api\/checkout"/g) || []).length !== 4) throw new Error('Purchase buttons must use the Stripe redirect route');
execFileSync(process.execPath, ['tests/integration.test.mjs'], { stdio: 'inherit' });
console.log('Build validated. Vercel serves public/ and deploys api/ functions separately.');
