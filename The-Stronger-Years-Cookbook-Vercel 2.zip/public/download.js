const params = new URLSearchParams(location.search);
const session = params.get('session_id') || sessionStorage.getItem('cookbook_session');
if (params.get('session_id')) {
  sessionStorage.setItem('cookbook_session', session);
  history.replaceState(null, '', '/download');
}
const heading = document.querySelector('#heading');
const status = document.querySelector('#status');
const link = document.querySelector('#download');
const retry = document.querySelector('#retry');
const expiry = document.querySelector('#expiry');
let attempts = 0, timer, running = false;
function showRetry(message) { status.textContent = message; retry.hidden = false; }
async function check() {
  if (running) return;
  running = true;
  retry.hidden = true;
  link.hidden = true;
  clearTimeout(timer);
  if (!session) {
    heading.textContent = 'Your cookbook awaits.';
    status.textContent = 'Complete your purchase to access your cookbook. If you already paid, return to this page in the same browser you used for checkout.';
    running = false; return;
  }
  try {
    const response = await fetch('/api/access?session_id=' + encodeURIComponent(session), { cache: 'no-store', credentials: 'same-origin' });
    const data = await response.json();
    if (data.status === 'ready' && response.ok) {
      heading.textContent = 'Thank you for your purchase!';
      status.textContent = 'Your cookbook is ready. Here’s to good food and a fresh chapter.';
      link.href = data.download_url;
      link.hidden = false;
      expiry.textContent = 'This download link expires in 15 minutes. You can refresh your link on this page within 24 hours of payment confirmation.';
      timer = setTimeout(() => { link.hidden = true; showRetry('Your download link has expired. Check again for a fresh link.'); }, Math.max(0, data.expires_at * 1000 - Date.now()));
    } else if (data.status === 'pending') {
      heading.textContent = 'We’re confirming your payment.';
      status.textContent = 'Your download will appear after payment confirmation. Some payment methods take longer to process.';
      if (++attempts < 12) timer = setTimeout(check, 5000);
      else showRetry('Your payment is still being confirmed. Keep this page and check again later.');
    } else if (data.status === 'failed') {
      heading.textContent = 'Your payment was not completed.';
      status.textContent = 'Your payment provider could not complete this payment. Return to the cookbook page to try again.';
    } else if (data.status === 'expired') {
      heading.textContent = 'Your access window has ended.';
      status.textContent = 'Return to the seller with your payment receipt if you still need your cookbook. You do not need to purchase it again.';
    } else {
      heading.textContent = 'We couldn’t verify your access.';
      showRetry('Use the same browser you used for checkout. If you already paid and this continues, contact the seller with your receipt.');
    }
  } catch { showRetry('We couldn’t connect. Please check your connection and try again.'); }
  running = false;
}
retry.addEventListener('click', () => { attempts = 0; check(); });
check();
