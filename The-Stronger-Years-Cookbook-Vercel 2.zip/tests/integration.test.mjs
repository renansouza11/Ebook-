import test from 'node:test';
import assert from 'node:assert/strict';
import Stripe from 'stripe';
import { PAYMENT_LINK_URL, COOKIE, sha, signToken, verifyToken, paidProduct, withinWindow } from '../lib/security.mjs';
import { fulfill } from '../lib/server.mjs';
import { GET as checkout } from '../api/checkout.js';
import { POST as webhook } from '../api/webhook.js';
import { GET as access } from '../api/access.js';
import { GET as download } from '../api/download.js';
process.env.STRIPE_RESTRICTED_KEY = 'rk_test_placeholder';
process.env.STRIPE_WEBHOOK_SECRET = 'whsec_placeholder';
process.env.DOWNLOAD_SIGNING_SECRET = 'a'.repeat(64);
process.env.SITE_URL = 'https://example.com';
const now = Math.floor(Date.now()/1000), browser = 'b'.repeat(64);
function session(extra = {}) { return { id: 'cs_test_paid123', payment_link: 'plink_test_123', client_reference_id: sha(browser), _verified_product: true, mode: 'payment', status: 'complete', payment_status: 'paid', currency: 'usd', amount_total: 900, metadata: { fulfilled_at: String(now) }, payment_intent: { status: 'succeeded', latest_charge: { paid: true, refunded: false, amount_refunded: 0, disputed: false } }, ...extra }; }
function request(path, options = {}) { return new Request('https://example.com' + path, { ...options, headers: { cookie: COOKIE + '=' + browser, ...options.headers } }); }
const originalFetch = global.fetch;
function stripeMock(value, linkUrl = PAYMENT_LINK_URL) { global.fetch = async url => { assert.match(String(url), /^https:\/\/api\.stripe\.com\//); return new Response(JSON.stringify(String(url).includes('/payment_links/') ? { url: linkUrl } : value), { headers: { 'content-type': 'application/json' } }); }; }
test.afterEach(() => { global.fetch = originalFetch; });
test('paid product rejects wrong price, product, currency, incomplete and unpaid payments', () => {
  assert.equal(paidProduct(session()), true);
  for (const bad of [{ amount_total: 1 }, { currency: 'brl' }, { status: 'open' }, { payment_status: 'unpaid' }, { _verified_product: false }]) assert.equal(paidProduct(session(bad)), false);
});
test('tokens expire in 15 minutes and reject altered signatures or another browser', () => {
  const { token, exp } = signToken(session(), browser, now);
  assert.equal(exp, now + 900);
  assert.equal(verifyToken(token, request('/api/download'), now).sid, 'cs_test_paid123');
  assert.throws(() => verifyToken(token, request('/api/download'), now + 900));
  assert.throws(() => verifyToken(token + 'x', request('/api/download'), now));
  assert.throws(() => verifyToken(token, request('/api/download', { headers: { cookie: COOKIE + '=' + 'c'.repeat(64) } }), now));
});
test('link renewal stops 24 hours after fulfillment', () => {
  assert.equal(withinWindow(session(), now + 86400), false);
  assert.throws(() => signToken(session(), browser, now + 86400));
});
test('all purchase buttons lead to the protected redirect route', async () => {
  const { readFileSync } = await import('node:fs');
  const html = readFileSync('public/index.html', 'utf8');
  assert.equal((html.match(/href="\/api\/checkout"/g) || []).length, 4);
});
test('purchase route redirects to the exact Payment Link with a bound browser reference', async () => {
  const res = checkout(request('/api/checkout'));
  assert.equal(res.status, 303);
  const url = new URL(res.headers.get('location'));
  assert.equal(url.origin + url.pathname, PAYMENT_LINK_URL);
  assert.equal(url.searchParams.get('client_reference_id'), sha(browser));
  assert.match(res.headers.get('set-cookie'), /HttpOnly; Secure; SameSite=Lax/);
});
test('signed webhook grants access once and duplicates do not extend access', async () => {
  const paid = session({ metadata: {} });
  let updates = 0;
  const stripe = { checkout: { sessions: { retrieve: async () => paid, update: async (id, data, options) => { ++updates; assert.equal(options.idempotencyKey, 'ebook-fulfill-v1-' + id); paid.metadata = { ...paid.metadata, ...data.metadata }; } } }, paymentLinks: { retrieve: async () => ({ url: PAYMENT_LINK_URL }) } };
  const event = { type: 'checkout.session.completed', created: now, data: { object: { id: paid.id } } };
  await fulfill(stripe, event);
  await fulfill(stripe, { ...event, created: now + 60 });
  assert.equal(updates, 1);
  assert.equal(paid.metadata.fulfilled_at, String(now));
});
test('delayed payment is fulfilled only on paid async success', async () => {
  const paid = session({ payment_status: 'unpaid', metadata: {} });
  let updates = 0;
  const stripe = { checkout: { sessions: { retrieve: async () => paid, update: async () => ++updates } }, paymentLinks: { retrieve: async () => ({ url: PAYMENT_LINK_URL }) } };
  await fulfill(stripe, { type: 'checkout.session.completed', created: now, data: { object: { id: paid.id } } });
  assert.equal(updates, 0);
  paid.payment_status = 'paid';
  await fulfill(stripe, { type: 'checkout.session.async_payment_succeeded', created: now, data: { object: { id: paid.id } } });
  assert.equal(updates, 1);
});
test('webhook rejects invalid signature and tampered raw payload', async () => {
  const sdk = new Stripe('rk_test_placeholder');
  const body = JSON.stringify({ id: 'evt_123', type: 'ignored', created: now, data: { object: {} } });
  const signature = sdk.webhooks.generateTestHeaderString({ payload: body, secret: process.env.STRIPE_WEBHOOK_SECRET });
  assert.equal((await webhook(request('/api/stripe-webhook', { method: 'POST', body, headers: { 'stripe-signature': 'invalid' } }))).status, 400);
  assert.equal((await webhook(request('/api/stripe-webhook', { method: 'POST', body: body + ' ', headers: { 'stripe-signature': signature } }))).status, 400);
  assert.equal((await webhook(request('/api/stripe-webhook', { method: 'POST', body, headers: { 'stripe-signature': signature } }))).status, 200);
});
test('download is unavailable without valid signed token', async () => {
  const res = await download(request('/api/download?token=fake'));
  assert.equal(res.status, 403);
});
test('access waits for paid webhook fulfillment', async () => {
  stripeMock(session({ metadata: {} }));
  const res = await access(request('/api/access?session_id=cs_test_paid123'));
  assert.equal(res.status, 202);
  assert.equal((await res.json()).status, 'pending');
});
test('a different Stripe Payment Link cannot unlock this ebook', async () => {
  stripeMock(session(), 'https://buy.stripe.com/another-product');
  assert.equal((await access(request('/api/access?session_id=cs_test_paid123'))).status, 403);
});
test('access requires the checkout browser even with a valid session id', async () => {
  stripeMock(session());
  assert.equal((await access(request('/api/access?session_id=cs_test_paid123', { headers: { cookie: '' } }))).status, 403);
});
test('access returns a temporary link for fulfilled paid checkout', async () => {
  stripeMock(session());
  const res = await access(request('/api/access?session_id=cs_test_paid123'));
  assert.equal(res.status, 200);
  assert.equal(res.headers.get('cache-control'), 'no-store, private, max-age=0');
  assert.match((await res.json()).download_url, /^\/api\/download\?token=/);
});
test('refunded or disputed payments cannot download', async () => {
  const { token } = signToken(session(), browser);
  for (const change of [{ amount_refunded: 1 }, { refunded: true }, { disputed: true }]) {
    const paid = session(); Object.assign(paid.payment_intent.latest_charge, change);
    stripeMock(paid);
    assert.equal((await download(request('/api/download?token=' + token))).status, 403);
  }
});
test('authorized download streams the actual private PDF', async () => {
  stripeMock(session());
  const { token } = signToken(session(), browser);
  const res = await download(request('/api/download?token=' + token));
  assert.equal(res.status, 200);
  assert.equal(res.headers.get('content-type'), 'application/pdf');
  const bytes = Buffer.from(await res.arrayBuffer());
  assert.equal(bytes.subarray(0,5).toString(), '%PDF-');
  assert.equal(bytes.length, 5372579);
});
