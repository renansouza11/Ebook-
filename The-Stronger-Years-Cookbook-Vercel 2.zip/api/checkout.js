import { PAYMENT_LINK_URL, COOKIE, browserSecret, nonce, sha } from '../lib/security.mjs';
import { headers } from '../lib/server.mjs';

export function GET(request) {
  let value = browserSecret(request);
  if (!/^[a-f0-9]{64}$/.test(value)) value = nonce();
  const url = new URL(PAYMENT_LINK_URL);
  url.searchParams.set('client_reference_id', sha(value));
  return new Response(null, { status: 303, headers: {
    ...headers,
    Location: url.href,
    'Set-Cookie': `${COOKIE}=${value}; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=2592000`,
  } });
}
