import { createReadStream } from 'node:fs';
import { stat } from 'node:fs/promises';
import { resolve } from 'node:path';
import { Readable } from 'node:stream';
import { client, getSession, json, headers } from '../lib/server.mjs';
import { verifyToken, requireBrowser, paidProduct, refundableAccess, withinWindow } from '../lib/security.mjs';
async function handler(request) {
  if (request.method !== 'GET') return json({ error: 'Method not allowed' }, 405);
  try {
    const payload = verifyToken(new URL(request.url).searchParams.get('token'), request);
    const session = await getSession(client(), payload.sid);
    requireBrowser(request, session);
    if (!paidProduct(session) || !refundableAccess(session) || !withinWindow(session)) return json({ error: 'Access unavailable' }, 403);
    const path = resolve(process.cwd(), 'private/ebook.pdf');
    const info = await stat(path);
    // Stream the PDF: its size exceeds the binary limit of buffered Lambda responses.
    return new Response(Readable.toWeb(createReadStream(path)), { headers: { ...headers,
      'Content-Type': 'application/pdf', 'Content-Length': String(info.size),
      'Content-Disposition': 'attachment; filename="The-Stronger-Years-Cookbook.pdf"',
      'X-Robots-Tag': 'noindex, nofollow, noarchive',
    } });
  } catch (error) {
    return json({ error: 'This download link is invalid or expired. Return to the download page to try again.' }, error.message === 'denied' ? 403 : 503);
  }
}
export async function GET(request) { return handler(request); }
