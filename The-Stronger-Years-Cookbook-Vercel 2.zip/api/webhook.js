import { client, fulfill, json } from '../lib/server.mjs';
async function handler(request) {
  if (request.method !== 'POST') return json({ error: 'Method not allowed' }, 405);
  let stripe, event;
  try {
    stripe = client();
    if (!process.env.STRIPE_WEBHOOK_SECRET) return json({ error: 'Unavailable' }, 503);
  } catch { return json({ error: 'Unavailable' }, 503); }
  try {
    // Raw body is essential: never parse JSON before constructEvent.
    event = stripe.webhooks.constructEvent(await request.text(), request.headers.get('stripe-signature'), process.env.STRIPE_WEBHOOK_SECRET);
  } catch { return json({ error: 'Invalid signature' }, 400); }
  try {
    await fulfill(stripe, event);
    return json({ received: true });
  } catch { return json({ error: 'Retry required' }, 503); }
}
export async function POST(request) { return handler(request); }
