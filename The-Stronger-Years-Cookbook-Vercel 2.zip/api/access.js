import { client, getSession, json } from '../lib/server.mjs';
import { requireBrowser, paidProduct, refundableAccess, fulfillmentTime, signToken, withinWindow } from '../lib/security.mjs';
async function handler(request) {
  if (request.method !== 'GET') return json({ error: 'Method not allowed' }, 405);
  try {
    const session = await getSession(client(), new URL(request.url).searchParams.get('session_id'));
    const value = requireBrowser(request, session);
    if (session.metadata?.payment_failed_at && session.payment_status !== 'paid') return json({ status: 'failed' }, 402);
    if (!paidProduct(session)) return json({ status: session.status === 'expired' ? 'expired' : 'pending' }, 202);
    if (!refundableAccess(session)) return json({ status: 'unavailable' }, 403);
    if (!fulfillmentTime(session)) return json({ status: 'pending' }, 202);
    if (!withinWindow(session)) return json({ status: 'expired' }, 410);
    const { token, exp } = signToken(session, value);
    return json({ status: 'ready', download_url: '/api/download?token=' + token, expires_at: exp });
  } catch (error) {
    return json({ status: 'unavailable' }, error.message === 'denied' ? 403 : 503);
  }
}
export async function GET(request) { return handler(request); }
